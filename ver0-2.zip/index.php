<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>BELISSIMO - auto-installer for MODX website templates by Ardius.net</title>
        <!-- Font Awesome icons (free version)-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" crossorigin="anonymous"></script>
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet">
        <!-- Fonts CSS-->
        <link rel="stylesheet" href="css/heading.css">
        <link rel="stylesheet" href="css/body.css">
        <link href="css/notifIt.css" type="text/css" rel="stylesheet">

    </head>
    <body id="page-top">
        <header class="masthead bg-primary text-white text-center">
            <div class="container d-flex align-items-center flex-column">
                <!-- Masthead Avatar Image--><img class="masthead-avatar mb-5" id="rabbit0" src="assets/logo.png" alt="">
                <!-- Masthead Heading-->
                <h1 class="masthead-heading mb-0">BELISSIMO</h1>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Masthead Subheading-->
                <p class="pre-wrap masthead-subheading font-weight-light mb-0">С помощью автоустановщика вы сможете установить шаблон из каталога или архива на Modx Revo.
Поддержать проект можно через Ядекс Деньги:  41001752083175 или помогая развавать проект.<br>
</p>
<b id="ver"></b>
            </div>
        </header>
        <section class="page-section portfolio" id="portfolio">
            <div class="container">
                <!-- Portfolio Section Heading-->
                <div class="text-center">
                    <h2 class="page-section-heading text-secondary mb-0 d-inline-block">УСТАНОВЩИК</h2>
                </div>
<div class="divider-custom divider">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><svg class="svg-inline--fa fa-star fa-w-18" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="star" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" data-fa-i2svg=""><path fill="currentColor" d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path></svg><!-- <i class="fas fa-star"></i> --></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Icon Divider-->
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" data-toggle="tab" href="#sear">Поиск шаблонов</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-toggle="tab" href="#archive">Установка из архива</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-toggle="tab" href="#option">Настройки установки и форма поиска</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-toggle="tab" href="#teach">Видеоуроки по работе</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-toggle="tab" href="#update">Обновления и версии</a>
  </li>
</ul>
<div class="tab-content">
  <div class="tab-pane fade show active" id="sear">
                    <div id="templates" class="row justify-content-center"></div>
               <div class="text-center">
			   <img id="load" src="assets/loading.gif"><br>
<button  class="btn btn-primary" page="12" id="nextpage" href="#">ДАЛЕЕ</button>
</div>
  </div>
  <div class="tab-pane fade" id="archive">
    <form id="upload" method="post" action="upload.php" enctype="multipart/form-data">
            <div id="drop">
                Переместите только один .ZIP архив сюда или выберите его вручную с устройства<br>
Весь шаблон должен быть помещён в подпапку внутри архива!

                <br><a>ВЫБРАТЬ</a>
                <input type="file" name="upl" multiple />
            </div>

            <ul>
                <!-- The file uploads will be shown here -->
            </ul>

        </form>
  </div>
<div class="tab-pane fade" id="option">
<div class="row text-center">
<div class="col-sm-4 text-left">
<div class="form-check">
  <input type="checkbox" class="form-check-input" id="no-chunk">
  <label class="form-check-label" for="materialIndeterminate2">НЕ ГЕНЕРИРОВАТЬ ЧАНКИ</label>
</div>
<div class="form-check">
  <input type="checkbox" class="form-check-input" id="sandbox" checked>
  <label class="form-check-label" for="materialIndeterminate2">IFRAME В РЕЖИМЕ ПЕСОЧНИЦЫ</label>
</div>
</div>
<div class="col-sm-4 text-left">
<div class="form-check">
  <input type="checkbox" class="form-check-input" id="no-link">
  <label class="form-check-label" for="materialIndeterminate2">НЕ ГЕНЕРИРОВАТЬ ССЫЛКИ</label>
</div>
</div>
<div class="col-sm-4 text-left" style="margin-bottom: 30px;" >
<div class="custom-control custom-radio">
  <input type="radio" class="custom-control-input" id="defaultGroupExample1" name="groupOfDefaultRadios">
  <label class="custom-control-label" for="defaultGroupExample1">Искать только одностраничники</label>
</div>

<!-- Group of default radios - option 2 -->
<div class="custom-control custom-radio">
  <input type="radio" class="custom-control-input" id="defaultGroupExample2" name="groupOfDefaultRadios">
  <label class="custom-control-label" for="defaultGroupExample2">Искать только многостраничники</label>
</div>
<div class="custom-control custom-radio">
  <input type="radio" class="custom-control-input" id="defaultGroupExample3" name="groupOfDefaultRadios">
  <label class="custom-control-label" for="defaultGroupExample3">Искать только Bootstrap</label>
</div>
<div class="custom-control custom-radio">
  <input type="radio" class="custom-control-input" id="defaultGroupExample4" name="groupOfDefaultRadios" checked>
  <label class="custom-control-label" for="defaultGroupExample4">Искать все</label>
</div>
</div>
<div class="col-sm-4 text-left" style="margin-bottom: 30px;" >

<div onclick="catalog_name('freecss');" class="form-check">
  <input type="checkbox" id="freecss" class="form-check-input">
  <label class="form-check-label" for="materialIndeterminate2">Выводить шаблоны с сайта free-css.com</label>
</div>
<div onclick="catalog_name('html5up');" class="form-check">
  <input type="checkbox" id="html5up" class="form-check-input">
  <label class="form-check-label" for="materialIndeterminate2">Выводить шаблоны с сайта html5up.net</label>
</div>
</div>

<div class="col-sm-12">
<p>
Список категорий для поиска
</p>
<ul id="taglist" class="clear">
  <li><a href="agriculture">Сельское хозяйство</a></li>
<li><a href="hosting">Хостинг</a></li>
<li><a href="alternative-power">Альтернативная энергетика и электричество</a></li>
<li><a href="hotels">Отели</a></li>
<li><a href="animals-or-pets">Животные</a></li>
<li><a href="icons">Иконки</a></li>
<li><a href="antique">Антиквариат</a></li>
<li><a href="industry">Индустрия</a></li>
<li><a href="app-or-application">Софт</a></li>
<li><a href="interface">Интерфейс</a></li>
<li><a href="architecture">Архитектура</a></li>
<li><a href="interior-or-furniture">Интерьер и мебель</a></li>
<li><a href="art-or-photography">Искуство и фотография</a></li>
<li><a href="internet">Интернет</a></li>
<li><a href="beauty">Красота</a></li>
<li><a href="jewellery">Украшения</a></li>
<li><a href="blog">Блоги</a></li>
<li><a href="jquery">jQuery</a></li>
<li><a href="books">Книжные</a></li>
<li><a href="law">Юридические</a></li>
<li><a href="brewery">Пиво и закуски</a></li>
<li><a href="lawyer-or-legal">Юридические услуги</a></li>
<li><a href="business">Бизнес</a></li>
<li><a href="lifestyle">Лайфстайл</a></li>
<li><a href="bootstrap">Bootstrap</a></li>
<li><a href="magazine">Журнал</a></li>
<li><a href="cafe-or-restaurant">Кафе и рестораны</a></li>
<li><a href="marketing">Маркетинг</a></li>
<li><a href="cars">Автомобили</a></li>
<li><a href="media">Медиа</a></li>
<li><a href="celebration">Праздник и события</a></li>
<li><a href="medical">Медицина</a></li>
<li><a href="charity">Благотворительность</a></li>
<li><a href="military">Военный</a></li>
<li><a href="christmas">Празники</a></li>
<li><a href="minimalistic">Минималистичные</a></li>
<li><a href="clean">Уборка</a></li>
<li><a href="communications">Связь</a></li>
<li><a href="music">Музыка</a></li>
<li><a href="computers">Компьютеры</a></li>
<li><a href="news">Новостные</a></li>
<li><a href="control-panel">Админ. панели</a></li>
<li><a href="night-club">Ночные клубы</a></li>
<li><a href="corporate">Корпоративные</a></li>
<li><a href="online-shop">Интернет магазины</a></li>
<li><a href="dating">Знакомства</a></li>
<li><a href="design">Дизайн</a></li>
<li><a href="outdoors">Природа</a></li>
<li><a href="eco">Эко</a></li>
<li><a href="personal">Личный</a></li>
<li><a href="ecommerce">Электронная коммерция</a></li>
<li><a href="politics">Политика</a></li>
<li><a href="education">Обучение</a></li>
<li><a href="portal">Электронный портал</a></li>
<li><a href="electronics">Электроника</a></li>
<li><a href="portfolio">Портфолио</a></li>
<li><a href="entertainment">Развлечения</a></li>
<li><a href="premium">Премиальные</a></li>
<li><a href="environmental">Экология</a></li>
<li><a href="real-estate">Недвижимость</a></li>
<li><a href="events">События</a></li>
<li><a href="religion">Религия</a></li>
<li><a href="exterior-design">Дизайн недвижимости</a></li>
<li><a href="responsive">Адаптивные</a></li>
<li><a href="family">Семейные</a></li>
<li><a href="school">Школа</a></li>
<li><a href="fashion">Мода</a></li>
<li><a href="science">Наука</a></li>
<li><a href="finance">Финансы</a></li>
<li><a href="security">Безопасность</a></li>
<li><a href="fitness">Фитнес</a></li>
<li><a href="services">Сервис</a></li>
<li><a href="flowers">Цветы</a></li>
<li><a href="society-or-culture">Общество и культура</a></li>
<li><a href="food-or-drink">Еда и напистки</a></li>
<li><a href="software">Программное обеспечение</a></li>
<li><a href="forum">Форум</a></li>
<li><a href="sport">Спорт</a></li>
<li><a href="gallery">Галлереи</a></li>
<li><a href="tools-or-equipment">Инструменты и обмундирование</a></li>
<li><a href="games">Игры</a></li>
<li><a href="transport">Транспорт</a></li>
<li><a href="gifts">Подарки</a></li>
<li><a href="travel">Путешествия</a></li>
<li><a href="government">Правительство</a></li>
<li><a href="tv-or-radio">Телевидение и Радио</a></li>
<li><a href="health-or-healthcare">Здоровье и больницы</a></li>
<li><a href="webdesign">Веб-дизайн</a></li>
<li><a href="holiday">Праздники</a></li>
<li><a href="wedding">Свадьбы</a></li>

</ul>
</div>     
</div>
  </div>
<div class="tab-pane fade" id="teach">
 <div id="junior" class="row justify-content-center"></div>
</div>
<div class="tab-pane fade" id="update">
 <div id="up" class="row justify-content-center"></div>  
</div>
</div>
</div>

            </div>
        </section>

        <section class="page-section bg-primary text-white mb-0" id="about">
            <div class="container">
                <!-- About Section Heading-->
                <div class="text-center">
                    <h2 class="page-section-heading d-inline-block text-white"><i class="fas fa-universal-access"></i>     Что он может?</h2>
                </div>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- About Section Content-->
                <div style="text-transform: uppercase;" class="row text-center">
                    <div class="col-lg-4 ml-auto">
                        <p class="pre-wrap lead"><i class="fas fa-sitemap"></i><br>Создаёт: чанки, категорию и ресурсы для шаблона</p>
                    </div>
					<div class="col-lg-4 mr-auto">
                        <p class="pre-wrap lead"><i class="fas fa-database"></i><br>Выбор шаблона из каталога на 3000+ шаблонов</p>
                    </div>
					<div class="col-lg-4 mr-auto">
                        <p class="pre-wrap lead"><i class="fas fa-cogs"></i><br>Изменит шаблон под структуру сайта</p>
                    </div>
					<div class="col-lg-4 mr-auto">
                        <p class="pre-wrap lead"><i class="fas fa-search"></i><br>Уставновка параметров при поиске шаблона</p>
                    </div>
					<div class="col-lg-4 mr-auto">
                        <p class="pre-wrap lead"><i class="fas fa-archive"></i><br>Если каталога мало, установите из .ZIP архива</p>
                    </div>
                    <div class="col-lg-4 mr-auto">
                        <p class="pre-wrap lead"><i class="fas fa-code"></i><br>В коде скрипта коментарии почти к каждой строчке</p>
                    </div>
					
                </div>
            </div>
        </section>
        <section class="page-section" id="contact">
            <div class="container">
                <!-- Contact Section Heading-->
                <div class="text-center">
                    <h2 class="page-section-heading text-secondary d-inline-block mb-0"><i class="fas fa-exclamation-triangle"></i>     Напишите нам</h2><br><p>Если вы нашли ошибку или хотите что-то предложить то напишите нам</p>
                </div>
                <!-- Icon Divider-->
                <div class="divider-custom">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Contact Section Content-->
                <div class="row justify-content-center">
                    <div class="col-lg-4">
                        <div class="d-flex flex-column align-items-center">
                            <div class="text-muted">Email</div><a class="lead font-weight-bold" href="mailto:contact@ardius.net">contact@ardius.net</a>
                        </div>
                    </div>
                       <div class="col-lg-4">
                        <div class="d-flex flex-column align-items-center">
                            <div class="text-muted">Через форму на сайте</div><a class="lead font-weight-bold" href="https://ardius.net/#contact">https://ardius.net/#contact</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Copyright Section-->
        <section class="copyright py-4 text-center text-white">
            <div class="container"><small class="pre-wrap">Шаблон данного установщика https://startbootstrap.com/themes/freelancer/  </small> <br><p>Автоустановщик разработан веб-студией <a id="rabbit1" href="https://ardius.net" target="_blank" >Ardius.net</a></p></div>
        </section>
        <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes)-->
        <div class="scroll-to-top d-lg-none position-fixed"><a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top"><i class="fa fa-chevron-up"></i></a></div>
        <!-- Bootstrap core JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <!-- Third party plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <!-- jQuery File Upload Dependencies -->
        <script src="js/jquery.knob.js"></script>
        <script src="js/jquery.ui.widget.js"></script>
        <script src="js/jquery.iframe-transport.js"></script>
        <script src="js/jquery.fileupload.js"></script>
        <script src="js/notifIt.js" type="text/javascript"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
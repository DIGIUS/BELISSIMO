function randomInteger(min, max) {
  // получить случайное число от (min-0.5) до (max+0.5)
  let rand = min - 0.5 + Math.random() * (max - min + 1);
  return Math.round(rand);
}
//для паскахлки использован видос https:\/\/www\.youtube\.com\/watch\?v\=\1di\-Q9kKS88
var _0x5d52=['Нехрен\x20было\x20тыкать\x20сюда!)','reload','height','#rabbit1','click','volume','src','body','width','<img\x20class=\x22mlg\x22\x20src=\x22https://ardius.net/mlg/','px;z-inndex:\x209999;\x20transform:\x20rotate(','.mlg','autoplay','px;\x20height:\x20auto;\x20position:\x20fixed;top:','remove','<audio\x20src=\x22https://ardius.net/rabbit.webm\x22\x20autoplay=\x22autoplay\x22></audio>','.gif\x22\x20style=\x22width:\x20','Спасибо\x20что\x20кликнул\x204\x20раза,\x20вот\x20тебе\x20за\x20это\x20подарок!','append','#rabbit0','html'];(function(_0x36da06,_0x5d52ed){var _0x5b075d=function(_0x23a892){while(--_0x23a892){_0x36da06['push'](_0x36da06['shift']());}};_0x5b075d(++_0x5d52ed);}(_0x5d52,0x14a));var _0x5b07=function(_0x36da06,_0x5d52ed){_0x36da06=_0x36da06-0x0;var _0x5b075d=_0x5d52[_0x36da06];return _0x5b075d;};var tab=0x0;function mlg(){var _0x7045dd=$(window)[_0x5b07('0xe')](),_0x12910e=$(window)[_0x5b07('0x8')]();let _0x1abdb6=setInterval(()=>$(_0x5b07('0xd'))[_0x5b07('0x3')](_0x5b07('0xf')+randomInteger(0x1,0xb)+_0x5b07('0x1')+randomInteger(0x12c,0x190)+_0x5b07('0x13')+randomInteger(0x0,_0x12910e)+'px;left:'+randomInteger(0x0,_0x7045dd)+_0x5b07('0x10')+randomInteger(0x0,0x168)+'deg);\x22>'),0x320);setTimeout(()=>{clearInterval(_0x1abdb6),$(_0x5b07('0x11'))[_0x5b07('0x14')]();},0xbf68);}$(_0x5b07('0x4'))[_0x5b07('0xa')](function(){tab++;if(tab>0xa){alert(_0x5b07('0x6')),mlg(),$(_0x5b07('0x5'))[_0x5b07('0x3')](_0x5b07('0x0'));var _0x641f97=new Audio();_0x641f97[_0x5b07('0xc')]='https://ardius.net/rabbit.webm',_0x641f97[_0x5b07('0x12')]=!![],_0x641f97[_0x5b07('0xb')]=0.1,setTimeout(function(){location[_0x5b07('0x7')]();},0xbf68),tab=0x0;}}),$(_0x5b07('0x9'))[_0x5b07('0xa')](function(){tab++;if(tab>0x3)return alert(_0x5b07('0x2')),$(_0x5b07('0xd'))[_0x5b07('0x5')]('<video\x20id=\x22egg\x22\x20style=\x22width:\x20100%;height:100%;top:0px;left:0px;position:fixed;\x22\x20autoplay><source\x20src=\x22https://ardius.net/rabbit.webm\x22\x20type=\x22video/mp4\x22></video>'),setTimeout(function(){location['reload']();},0xbf68),![],tab=0x0;});
$('#load').fadeIn(500);
page(0);
var chunk = 0;
var href = 0;
var searchtype = 0;
var search  = '';
var sand = 1;
support();
$('#html5up').prop('checked', false);
$('#freecss').prop('checked', true);
var ver = Number('0.2'); //номер версии
$('#ver').text('Версия '+ver);
function catalog_name(name){
switch (name) {
  case 'html5up':
		$('#freecss').prop('checked', false);
		$('#html5up').prop('checked', true);
		$('#templates').html('');
		$('#load').fadeIn(500);
		page(0,'https://html5up.net');
		 $('.nav.nav-tabs .nav-item a').eq(0).click();
		 $('#nextpage').hide();
    break;
  default: //free-css.com идет по умолчанию
		$('#html5up').prop('checked', false);
		$('#freecss').prop('checked', true);
		$('#load').fadeIn(500);
		$('#templates').html('');
		page(0);
		$('#nextpage').attr('page','12');
		$('.nav.nav-tabs .nav-item a').eq(0).click();
		$('#nextpage').show();
}		
}
function nver_download(url){
$.post("getpage.php",{update: 'update', href: url},onSuccess);
function onSuccess(data){
console.log(data);
if(data==='good'){location.reload();}
if(data==='bad'){alert('При обновлении произошла ошибка, обновите вручную.');}
}
}
function support(){
$.post("getpage.php",{update: 'update'},onSuccess);
function onSuccess(data){
$('#up').html(data);
$('.table tbody tr td').each(function( index ) {
 var text = $( this ).text();
 if(text.search('Версия') != -1){
text = Number(text.replace(/[^\d.]/g, ''));
console.log(text+' '+ver);
if(text>ver){
	notif({
  type: "warning",
  msg: '<i class="fa fa-bullhorn" aria-hidden="true"></i> Обнаружена новая версия, посетите вкладку "Обновления и версии"',
  width: "all",
  width: 600,
  autohide: false,
  position: "center"
});
}
 
 }
});
}
$.post("getpage.php",{video: 'video'},onAjaxSuccess);
function onAjaxSuccess(data){
$('#junior').html(data);
}
}
function showmodal(url,title){
	
	$.post("getpage.php",
  {
    getp:   url,
	sandbox: sand
  },
  onAjaxSuccess
);
function onAjaxSuccess(data){
	console.log(data);
  if(data.length>0){
$('#templates').html($('#templates').html()+data);
$('#'+title).attr('class','portfolio-modal modal show');
$('#'+title).fadeIn(500);
} 	
}
}
function install(url,name0){
$.post("getpage.php",
  {
    install:   url,
	name:      name0,
	chunks: chunk,
	hrefs: href
  },
  onAjaxSuccess
);
notif({
  type: "info",
  msg: '<i class="fa fa-info" aria-hidden="true"></i> Установка началась',
  width: "all",
  width: 300,
  position: "center"
});
function onAjaxSuccess(data){
console.log(data);
notif({
  type: "success",
  msg: '<i class="fa fa-check" aria-hidden="true"></i> Шаблон был успешно установлен',
  position: "center",
  width: 300,
  autohide: true,
  multiline: true
});
}
return false;	
}
$('#nextpage').click(function(){
	var pag = parseInt($(this).attr('page'));
page(pag);
$(this).attr('page',pag+12);	
});	
function page(page){	
	$.post("getpage.php",
  {
    page:   page,
	sitetype: searchtype,
	sear: search
  },
  onAjaxSuccess
);
search = '';
function onAjaxSuccess(data){
$('#load').fadeOut(500);
console.log(data);
  if(data.length>0){
$('#templates').html($('#templates').html()+data);
}
}
}
function neww(url){
	window.open(url, "_blank", "top=100, left=100, width=800, height=400, scrollbars=yes, resizable=yes");
}
$(function(){

    var ul = $('#upload ul');

    $('#drop a').click(function(){
        // Simulate a click on the file input button
        // to show the file browser dialog
        $(this).parent().find('input').click();
    });

    // Initialize the jQuery File Upload plugin
    $('#upload').fileupload({

        // This element will accept file drag/drop uploading
        dropZone: $('#drop'),

        // This function is called when a file is added to the queue;
        // either via the browse button, or via drag/drop:
        add: function (e, data) {

            var tpl = $('<li class="working"><input type="text" value="0" data-width="48" data-height="48"'+
                ' data-fgColor="#0788a5" data-readOnly="1" data-bgColor="#3e4043" /><p></p><span></span></li>');

            // Append the file name and file size
            tpl.find('p').text(data.files[0].name)
                         .append('<i>' + formatFileSize(data.files[0].size) + '</i>');

            // Add the HTML to the UL element
            data.context = tpl.appendTo(ul);

            // Initialize the knob plugin
            tpl.find('input').knob();

            // Listen for clicks on the cancel icon
            tpl.find('span').click(function(){

                if(tpl.hasClass('working')){
                    jqXHR.abort();
                }

                tpl.fadeOut(function(){
                    tpl.remove();
                });

            });

            // Automatically upload the file once it is added to the queue
            var jqXHR = data.submit();
        },

        progress: function(e, data){

            // Calculate the completion percentage of the upload
            var progress = parseInt(data.loaded / data.total * 100, 10);

            // Update the hidden input field and trigger a change
            // so that the jQuery knob plugin knows to update the dial
            data.context.find('input').val(progress).change();

            if(progress == 100){
                data.context.removeClass('working');
            }
        },

        fail:function(e, data){
            // Something has gone wrong!
            data.context.addClass('error');
        }

    });


    // Prevent the default action when a file is dropped on the window
    $(document).on('drop dragover', function (e) {
        e.preventDefault();
    });

    // Helper function that formats the file sizes
    function formatFileSize(bytes) {
        if (typeof bytes !== 'number') {
            return '';
        }

        if (bytes >= 1000000000) {
            return (bytes / 1000000000).toFixed(2) + ' ГБ';
        }

        if (bytes >= 1000000) {
            return (bytes / 1000000).toFixed(2) + ' МБ';
        }

        return (bytes / 1000).toFixed(2) + ' КБ';
    }

});
function archive(){
$.post("getpage.php",
  {
    archive:   'template.zip',
	chunks: chunk,
	hrefs: href
  },
  onAjaxSuccess
);
notif({
  type: "info",
  msg: '<i class="fa fa-info" aria-hidden="true"></i> Установка началась',
  width: "all",
  width: 300,
  position: "center"
});
function onAjaxSuccess(data){
console.log(data);
notif({
  type: "success",
  msg: '<i class="fa fa-check" aria-hidden="true"></i> Шаблон был успешно установлен',
  position: "center",
  width: 300,
  autohide: true,
  multiline: true
});
}
}
$('#taglist li a').click(function(){
$('#load').fadeIn(500);
var tmp = $(this).attr('href');
search = tmp;
$('#templates').html('');
page(0);
$('#load').fadeOut(500);
$('#nextpage').attr('page','12');
$('.nav.nav-tabs .nav-item a').eq(0).click();
	return false;
});
$('#no-chunk').on('change', function(){
 if ($(this).is(":checked")){
chunk = 1;
 }else{
chunk = 0;
 }
 });
$('#no-link').on('change', function(){
 if ($(this).is(":checked")){
href = 1;
 }else{
href = 0;
 }
 });
$('#sandbox').on('change', function(){
 if ($(this).is(":checked")){
sand = 1;
 }else{
sand = 0;
 }
 });
$('#defaultGroupExample1').on('change', function(){
if ($(this).is(":checked")){
$('#load').fadeIn(500);
searchtype = 1;
$('#templates').html('');
page(0);
$('#load').fadeOut(500);
$('#nextpage').attr('page','12');
 $('.nav.nav-tabs .nav-item a').eq(0).click();
}
});
$('#defaultGroupExample2').on('change', function(){
 if ($(this).is(":checked")){
$('#load').fadeIn(500);
searchtype = 2;
$('#templates').html('');
page(0);
$('#load').fadeOut(500);
$('#nextpage').attr('page','12');
 $('.nav.nav-tabs .nav-item a').eq(0).click();
}
});
$('#defaultGroupExample3').on('change', function(){
 if ($(this).is(":checked")){
$('#load').fadeIn(500);
searchtype = 3;
$('#templates').html('');
page(0);
$('#load').fadeOut(500);
$('#nextpage').attr('page','12');
 $('.nav.nav-tabs .nav-item a').eq(0).click();
}
});
$('#defaultGroupExample4').on('change', function(){
 if ($(this).is(":checked")){
$('#load').fadeIn(500);
searchtype = 0;
$('#templates').html('');
page(0);
$('#load').fadeOut(500);
$('#nextpage').attr('page','12');
 $('.nav.nav-tabs .nav-item a').eq(0).click();
}
});
$("#upload ul").change(function() {
var file = ''; var i=0;
    $("#upload ul li p").each(function() {
     archive();
$('#upload ul li').remove();
file = '';
});
});
$('#taglist li a').click(function(){
	search($(this).attr('href'));
	return false;
});
<?php
define('MODX_API_MODE', true);
require '../index.php';
require 'libs/phptumb.php';
set_time_limit(36000);
ini_set("memory_limit", "1000M");
/*
не балуйтесь с exit(); и die; и другими останавливающими работу скрипта вещами (рискуете вручную удалять все что автоустановщик поставит), 
юзайте только функции и процедуры без остановки работы скрипта, например: var_dump, echo, print_r.
*/

global $chunks;
$chunks = false; // триггер автопереноса по чанкам (относительно корректно работает для одностраничников)
global $link;
$link = true; // триггер авторасстановки ссылок
global $type;
$type = 0; // по умолчанию искать все типы шаблонов
if(isset($_POST['sitetype'])){
$type = intval($_POST['sitetype']);
}
$sandbox = 1; //могут ли ссылки открываться из фрейма в текущем окне (некоторые шаблоны из за этого останавливаються на загрузке так как браузер блокирует загрузку скриптов), а некоторые открывают сайт оригинал в этом окне
if(isset($_POST['sandbox'])){
$sandbox = intval($_POST['sandbox']);
}
if($_POST['chunks'] ==='1'){
$chunks = false;	
}else{
$chunks = true;		
}
if($_POST['hrefs'] ==='1'){
$link = false;	
}else{
$link = true;		
}
function exist($file){ //поиск файла в папке
	if (file_exists($file)) {
    return true;
} else {
    return false;
}
}
function curl_themewagon($url){ //для этого сайта нужна кука, иначе не получить прямые ссылки на архивы
$curlHandler = curl_init();
curl_setopt_array($curlHandler, [
CURLOPT_URL => $url,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_COOKIEFILE  => $cookieFile,
CURLOPT_COOKIE => 'user_email=belissimo%40ardius.net;',
]);
$response = curl_exec($curlHandler);
curl_close($curlHandler);
$html = $response;
preg_match('/<h5>Tags<\/h5>\n.*<\/div>\n.*<div class="col-sm-7">\n.*<span><span class="single-theme-tax">(.*?)<\/span><\/span>/',$html,$out);
$tags =  $out[1];
preg_match_all('/rel="tag">(.*?)<\/a>/',$tags,$out);
$tags = array();foreach($out[1] as $tag){$tags[]=$tag;}
$tags = implode(', ',$tags); //финальный список тегов
preg_match('/<a class="live-preview-area" target="_blank" href="(.*?)" title="/',$html,$out);
$frame = $out[1]; //ссылка на фрейм
preg_match('/\'name\'\: \'(.*?)\'\,/',$html,$out);
$name = $out[1]; //название шаблона
preg_match('/<a id="directDownloadLink" href="(.*?)"/',$html,$out);
$download = $out[1]; //получаем ссылку на скачку
$out = array('name'=>$name,'tags'=>$tags,'frame'=>$frame,'download'=>$download);
return $out;
}
function themewagon(){ //генерация карточек с сайта
$html = getpage($pp);	
preg_match_all('/<figure>\n(.*?)<\/figure>/',$html,$out);	
$block = $out[1];
							
}
function unzip($file){ //разархивация зип архива только в папку downloads
$zip = new ZipArchive;
$res = $zip->open($file);
if ($res === TRUE) {
  $zip->extractTo('download/');
  $zip->close();
  return true;
} else {
  return false;
}	
}
function sear($word,$text){ //найти слово в тексте
$pos=strripos($text, $word);
if($pos === false){return false;}else{return true;}
}
function download($FromLocation,$ToLocation,$VerifyPeer=false,$VerifyHost=true){ //для скачки файлов
		$Channel = curl_init($FromLocation);
		$File = fopen ($ToLocation, "w");
		curl_setopt($Channel, CURLOPT_FILE, $File);
		curl_setopt($Channel, CURLOPT_HEADER, 0);
		curl_setopt($Channel, CURLOPT_SSL_VERIFYPEER, $VerifyPeer);
		curl_setopt($Channel, CURLOPT_SSL_VERIFYHOST, $VerifyHost);
		curl_exec($Channel);
		curl_close($Channel);
		fclose($File);
	return file_exists($ToLocation);
}
function getpage($url){ //получение кода сороннего сайта для парсинга
        $user_agent='Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0';

        
					$options = array(
		
			CURLOPT_SSL_VERIFYPEER => '0',
			CURLOPT_SSL_VERIFYHOST => '0',
            CURLOPT_CUSTOMREQUEST  =>"GET",
            CURLOPT_POST           =>false,
            CURLOPT_USERAGENT      => $user_agent,
            CURLOPT_COOKIEFILE     =>"cookie.txt",
            CURLOPT_COOKIEJAR      =>"cookie.txt",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING       => "",
            CURLOPT_AUTOREFERER    => true,
            CURLOPT_CONNECTTIMEOUT => 120,
            CURLOPT_TIMEOUT        => 120,
            CURLOPT_MAXREDIRS      => 10);
        $ch      = curl_init( $url );
        curl_setopt_array( $ch, $options );
        $content = curl_exec( $ch );
        $err     = curl_errno( $ch );
        $errmsg  = curl_error( $ch );
        $header  = curl_getinfo( $ch );
        curl_close( $ch );
        return $content;
}
function delDir($dir) { //удаление папки с её содержимым
    $files = array_diff(scandir($dir), ['.','..']);
    foreach ($files as $file) {
        (is_dir($dir.'/'.$file)) ? delDir($dir.'/'.$file) : unlink($dir.'/'.$file);
    }
    return rmdir($dir);
}
function loger($type,$val){ //создание файла с историей установки 
$fp = fopen('install.log', 'a');
fwrite($fp, "$type => $val\n");
fclose($fp);
}
function getfiletype($name){ //получение расширения файла примитивнийшим способом
return	substr($name, strrpos($name, '.' ) + 1 ); //получение расширения файла
}
function wayback(){ //для отката предыдущей установки шаблона
$story = read('install.log');
preg_match_all('/(.*?) => (.*?)\n/',$story,$story);
$story[1] = array_reverse($story[1]); //переворачиваем массивы поскольку нужно сначала удалить шаблоны а потом категорию. Так как процесс создания  другой: сначала категория, потом щаблоны.
$story[2] = array_reverse($story[2]);
for($i=0;$i<count($story[1]);$i++){
	switch ($story[1][$i]) {
    case 'category':
       rcategory(intval($story[2][$i]));
        break;
    case 'folder':
        delDir($story[2][$i]);
        break;
    case 'template':
        rtemplate($story[2][$i]);
        break;
	case 'res':
        rres($story[2][$i]);
        break;
	case 'chunk':
        rchunk($story[2][$i]);
        break;
	case 'file':
        unlink($story[2][$i]);
        break;
}
}
unlink('install.log'); //Удаление предыдущего файла истории установки
delDir('download/'); //удаление папки старых файлов 
delDir('../core/cache/'); //очистка кеша modx
mkdir('download/'); //создание папки для скачанных файлов
$files = array_diff(scandir('../assets/'), array('..', '.'));
foreach ($files as $file):
if($file !== 'components'){
delDir('../assets/'.$file); //удаление старых папок кроме папки модкс components
}
endforeach;
unlink('install.log');
}
function edit_image($in,$out,$l,$r,$u,$d){ //функция обрезки изображений, агрументами принимает: входное изображение, выходное изображение, отрезать: x, y , ширина и высота
$image = new Thumbs($in);
$image->crop($l, $l, $u, $d);
$image->save($out);
}
function chunk($name,$category,$content){ //функция добавления чанка
global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$modx->getService('error','error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_FATAL);
$modx->setLogTarget(XPDO_CLI_MODE ? 'ECHO' : 'HTML'); 
$chunk = $modx->newObject('modChunk');
$chunk->set('name',$name);
$chunk->set('category',$category);
$chunk->setContent($content);
$chunk->save();
$chunk->getPrimaryKey();
return $chunk->get('id');
}
function rchunk($id){ //функция удаления чанка
if(strlen($id)<=0){return;}
global $modx; 
$modx = new modX();
$modx->initialize('web');
$modx->getService('error','error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_FATAL);
$modx->setLogTarget(XPDO_CLI_MODE ? 'ECHO' : 'HTML'); 
$rchunk = $modx->getObject('modChunk', array('id' => $id));
if ($rchunk) $rchunk->remove();
}
function template($name,$category,$content){ //функция добавления шаблона
global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$template = $modx->newObject('modTemplate');
$template->set('templatename',$name);
$template->set('category',$category);
$template->setContent($content);
$template->save();
$template->getPrimaryKey();
return $template->get('id');
}
function rtemplate($id){ //Функция удаления шаблона
if(strlen($id)<=0){return;}
global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$modx->getService('error','error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_FATAL);
$modx->setLogTarget(XPDO_CLI_MODE ? 'ECHO' : 'HTML'); 
$rtemplate = $modx->getObject('modTemplate', array('id' => $id));
if ($rtemplate) $rtemplate->remove();
}
function category($name){ //Функция добавления шаблона
	global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$modx->getService('error','error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_FATAL);
$modx->setLogTarget(XPDO_CLI_MODE ? 'ECHO' : 'HTML'); 
$template = $modx->newObject('modCategory');
$template->set('parent','0');
$template->set('category',$name);
$template->save();
$template->getPrimaryKey();
return $template->get('id');
}
function rcategory($id){ //Функция удаления категории
if(strlen($id)<=0){return;}
	global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$modx->getService('error','error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_FATAL);
$modx->setLogTarget(XPDO_CLI_MODE ? 'ECHO' : 'HTML'); 
$category = $modx->getObject('modCategory', array('id' => $id));
if ($category) $category->remove();
}
function res($name,$category,$parent,$content){ //Функция добавления ресурса
global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$template = $modx->newObject('modResource');
$template->set('template',$category);
$template->set('alias',$name.' Ardius installed');
$template->set('parent',$parent);
$template->set('content',$content);
$template->set('published',1);
$template->set('pagetitle',$name);
$template->save();
$template->getPrimaryKey();
return $template->get('id');	
}
function rres($id){ //Функция удаления ресурса
if(strlen($id)<=0){return;}
global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$res = $modx->getObject('modResource', array('id' => $id));
if ($res) $res->remove(); //удаляем окончательно
}
function read($file){ //для того чтоб кодить было быстрее и писать меньше
return	file_get_contents($file); 
}
function getpatch($path){ //index.html или index.htm поиск в папках и вывод папки
	$path = new RecursiveDirectoryIterator($path);
$display = Array ( 'html', 'htm' );
foreach(new RecursiveIteratorIterator($path) as $file){
    if (in_array(strtolower(array_pop(explode('.', $file))), $display)){
        if(sear('index',$file)){
			$pp = str_replace('\\','/',$file);
			$pp = explode('/',$pp);
			array_pop($pp);
			$pp = implode("/", $pp).'/';
			return $pp;
		}
	}
}
}
function passer($path){ //основная функция, парсит, переносит, создаёт чанки, категорию, ресурсы и подгоняет под структуру Modx revo
$dir = array(); //массив для папок
$file = array(); //массив  для файлов
$files = scandir($path); //Получение списка файлов и папок в скачанной папке с шаблоном
for($i=2;$i<count($files);$i++){ //убрать из массива . и .. 
if(is_dir($path.$files[$i])){$dir[$i] = $files[$i];}  //в массив с папками 
if(is_file($path.$files[$i])){$file[$i] = $files[$i];}	//в массив с файлами
}
$dir = array_diff($dir, array('')); $file = array_diff($file, array(''));//удалить из массива пустые значения
$category = category($_POST['name']); //Создание категории чтоб небыло захламлённости и получение её ID
loger('Устанавливаемый шаблон ', $_POST['name'].', ссылка на шаблон '.$install); 
loger('Добавлена категория',$category);
loger('category',$category); //Добавление в лист установки ID нашей новой категории
$parent = res($_POST['name'],'0','0','Сгенерированно автоустановщиком шаблонов от Ardius.net
Отблагодорить можно через Ядекс.Деньги: 41001752083175');
loger('Добавлен ресурс',$parent);
loger('res',$parent); //Добавление в лист установки ID нашего нового родительского документа
foreach($dir as $np){//преемещение папок с ресурсами в папку asstes
loger('Перенесена папка в','../assets/'.$np);
loger('folder','../assets/'.$np); //добавление в гол файлов которые были перемещенны
rename($path.$np, '../assets/'.$np);
delDir($path.$np);
}
foreach($file as $np){//перебор всех файлов из папки с шаблоном
$html = read($path.$np);//чтение файла в переменную
if(sear('.html',$np) or sear('.htm',$np)){//если тпи фалов .html или .htm	
global $link;
if($link){ //если ссылки отключены, то не будут генерироваться
preg_match_all('/href="(.*?)"/',$html,$out);
foreach($out[0] as $href){
if(!sear('.css',$href)  and !sear('.js',$href)  and !sear('#',$href) and !sear('"tel:',$href) and !sear('"geo:',$href) and !sear('"mailto:',$href)){
foreach($file as $npp){//перебор всех файлов для замены ссылок
	$name = preg_replace("/\.[^.]+$/", "", $npp);
	$name = str_replace('/','-',$name);
	$name = str_replace('_','-',$name);
	$name = str_replace('.','-',$name);
	$name = str_replace('\\','-',$name);
	$html = str_replace($npp,'/'.$name.'-ardius-installed',$html);
}
}
}
}	
//восстанавливаем пути к скриптам и стилям после смены их папки
foreach($dir as $ns){
	$html = str_replace('="'.$ns,'="/assets/'.$ns,$html); //по хорошему установку предварительно нужно запихнуть в массив, потом открывать уже ресурсы и менять в них в соответствии с id, но это долго и мне пока лень...
}
//тут все предварительно 
//так как регулярки не распространяются на творчество разработчиков и все предугадать невозможно, но шаблонные варианты далее попробуем получить
//раскидываем общие значения по чанкам
global $chunks;
if($chunks){ //если чанки отключены, то не будут генерироваться
//Парсим META (если есть по паттерну)
preg_match_all('/<meta(?:.|\n|\r)+?>/',$html,$out); //получение всех js скриптов страницы
$meta = implode("\r\n", $out[0]); //сохранение всех js страницы в переменную
$last = array_pop($out[0]);
foreach($out[0] as $ext){
if(strlen($ext)> 0 and sear('<meta',$ext)){ //если находим то переводим в чанк, и чанк ставим в код
$html = str_replace($ext, '',$html);
}
}
$chunk =  chunk('meta_'.$_POST['name'],$category,$meta);
$html = str_replace($last, '[[$meta_'.$_POST['name'].']]',$html);	
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
//Парсим JS (если есть по паттерну)
preg_match_all('/<script.*?src=\"(.*?)\"/',$html,$out); //получение всех js скриптов страницы
$js = implode("\r\n", $out[0]); //сохранение всех js страницы в переменную
$last = array_pop($out[0]);
foreach($out[0] as $ext){
if(strlen($ext)> 0 and sear('<script',$ext)){ //если находим то переводим в чанк, и чанк ставим в код
$html = str_replace('="'.$ext, '',$html);
}
}
$chunk =  chunk('js_'.$_POST['name'],$category,$js);
$html = str_replace($last, '[[$js_'.$_POST['name'].']]',$html);	
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
//Парсим CSS (если есть по паттерну)
preg_match_all('/<link(?:.|\n|\r)+?>/',$html,$out); //получение всех css стилей страницы
$css = implode("|", $out[0]); //сохранение всех css страницы в переменную
preg_match_all('/<style(?:.|\n|\r)+?<\/style>/',$html,$out); //проверка стилей указанных вручную как это обычно бывает
if(count($out[0])===1){ //если в массиве единственное значение то implode не сработает
	$css.='|'.$out[0][0];
}else{
	$css.= implode("|", $out[0]);
}
$out = explode('|',$css);
$first= $out[0];
if(strlen($first)> 0 and sear('<\/style>',$first) or strlen($first)> 0 and sear('<link',$first)){ //если находим то переводим в чанк, и чанк ставим в код
foreach($out as $ext){
if($ext !== $first){
$html = str_replace('="'.$ext,'',$html);
}	
}
$css = str_replace('|',"\r\n",$css);
$chunk =  chunk('css_'.$_POST['name'],$category,$css);
$html = str_replace($first, '[[$css_'.$_POST['name'].']]',$html);
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);	
}
//Парсим HEAD (если есть по паттерну)
preg_match_all('/<head(?:.|\n|\r)+?head>/',$html,$out); //предварительное получение head
$head = $out[0][0]; //сохранение head страницы в переменную
if(strlen($head)>0 and sear('<head',$head) and sear('</head',$head)){ //если находим то переводим в чанк, и чанк ставим в код
$chunk =  chunk('head_'.$_POST['name'],$category,$head);
$html = str_replace($head, '[[$head_'.$_POST['name'].']]',$html);	
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
}
//Парсим FOOTER (если есть по паттерну)
preg_match_all('/<footer(?:.|\n|\r)+?footer>/',$html,$out); //предварительное получение footer
$footer = $out[0][0]; //сохранение footer страницы в переменную
if(strlen($footer)>0 and sear('<footer',$footer) and sear('</footer',$footer)){ //если находим то переводим в чанк, и чанк ставим в код
$chunk =  chunk('footer_'.$_POST['name'],$category,$footer);
$html = str_replace($footer, '[[$footer_'.$_POST['name'].']]',$html);	
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
}
//Парсим HEADER (если есть по паттерну)
preg_match_all('/<header(?:.|\n|\r)+?header>/',$html,$out); //предварительное получение header
$header = $out[0][0]; //сохранение header страницы в переменную
if(strlen($header)>0 and sear('<header',$header) and sear('</header',$header)){ //если находим то переводим в чанк, и чанк ставим в код
$chunk =  chunk('header_'.$_POST['name'],$category,$header);
$html = str_replace($header, '[[$header_'.$_POST['name'].']]',$html);	
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
}
//Парсим NAV (если есть по паттерну)
preg_match_all('/<nav(?:.|\n|\r)+?nav>/',$html,$out); //предварительное получение nav
$nav = $out[0][0]; //сохранение nav страницы в переменную
if(strlen($nav)>0 and sear('<nav',$nav) and sear('</nav>',$nav)){ //если находим то переводим в чанк, и чанк ставим в код
	$chunk =  chunk('navigation_'.$_POST['name'],$category,$nav);
	$html = str_replace($nav, '[[$navigation_'.$_POST['name'].']]',$html);
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);	
}
//preg_match_all('/<body(?:.|\n|\r)+?body>/',$html,$out); //предварительное получение body
//$body = $out[0][0]; //сохранение body страницы в переменную
//сохранение вариантов верстки
//я определил 3: первый секциями, второй вместо секций использует div с спец классом, третий неструктурированный и следовательно нерабочий для данного шаблонизатора
//триггерить эти блоки будем по словам: id="contact", class="contact"  
//тут мы и берём тесты верстки
//1 тип <section, пример кода: <section id="contact">
//Парсим SECTION (если есть по паттерну)
preg_match_all('/<section(?:.|\n|\r)+?<\/section>/',$html,$out);$last = $out[0][count($out[0])-1];
if(strlen($last)> 0 and sear('<section',$last)){ //если находим то переводим в чанк, и чанк ставим в код
$sec = 0;
foreach($out[0] as $sect){
$chunk =  chunk('section_'.$_POST['name'].'_'.preg_replace("/\.[^.]+$/", "", $np).'_'.$sec,$category,$sect);
$html = str_replace($sect, '[[$section_'.$_POST['name'].'_'.preg_replace("/\.[^.]+$/", "", $np).'_'.$sec.']]',$html);
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
$sec++;	
}
}
//2 тип <div class="contact", пример кода: <div class="contact" id="contact">
}
$template =  template(preg_replace("/\.[^.]+$/", "", $np),$category,$html);
loger('Создан шаблон',preg_replace("/\.[^.]+$/", "", $np));
loger('template',$template); //Добавление в лист установки ID нашего нового шаблона
$res = res(preg_replace("/\.[^.]+$/", "", $np),$template,$parent,'');
loger('Создан ресурс',preg_replace("/\.[^.]+$/", "", $np));
loger('res',$res); //Добавление в лист установки ID нашего нового родительского документа
}
if(!sear('.htm',$np) and !sear('.html',$np)){	!//если не файлы для шаблонов
//if($np !== 'config.core.php' or $np !== 'config.core.php' or $np !== '.htaccess'){ //защита если выложат шаблон с "кривыми файлами"
copy($path.$np, '../'.$np); //перенос файлов в основную папку сайта
loger('Скопирован файл в','../'.$np);
loger('file','../'.$np); //логируем перенос
unlink($path.$np); //удаление файлов из папки шаблона
//}
}
}
}
function html5up(){  //вывод каталога сайта html5up.net
$output = '';
$html = getpage('https://html5up.net/'); //получаем полный код сайта
preg_match('/<div\sid=\"items\"\>(.*?)\<\/body>/',$html,$out);//получаем ныжный кусок со всеми шаблонами
$html = $out[1];//получаем ныжный кусок со всеми шаблонами в первой ячейке парсинга
preg_match_all('/<article(.*?)<\/article>/',$html,$out); //режем код по блокам с шаблонами
foreach($out[1] as $html){ //начинаем цикл перебора кода с шаблонами
	preg_match('/class\=\"placeholder\"\salt="(.*?)"\s\/>/',$html,$out); //вырезаем название шаблона из альт тега
	$name = $out[1];
	$name = str_replace(' ','-',$name);
	//echo $name.PHP_EOL; //для отладки
	preg_match('/"\sdata\-src\=\"(.*?)\"\sclass\=\"placeholder\"?/',$html,$out); //вырезаем картинку из src
	$img = 'https://html5up.net/'.$out[1]; //собираем полную ссылку на сайт вместе с главной ссылкой на сайт
	//echo $img.PHP_EOL; //для отладки
	preg_match('/<\/span>Demo<\/a><a href="(.*?)" class="?/',$html,$out); //вырезаем ссылку на скачивание шаблона с сайта
	$link = 'https://html5up.net'.$out[1]; //собираем полную ссылку для скачивания вместе с главной ссылкой на сайт
	//echo $link.PHP_EOL; //для отладки
	preg_match('/class="actions"><a href="(.*?)" class="button demo"><span>Live <\/span>Demo<\/a>?/',$html,$out); //вырезаем ссылку на страницу предпросмотра
	$frame = 'https://html5up.net'.$out[1]; //собираем полную ссылку для просмотра превью вместе с главной ссылкой на сайт
	$filename = basename($img);
	if(!exist('cache/'.$filename)){ //проверяйм картинки в кеше, если они есть то не скачиваем
download($img,'cache/'.$filename); //сайт защищен от просмотра картинок с другого ip, для этого скачиваем их и выводим локально
edit_image('cache/'.$filename,'cache/'.$filename,69,102,650,270);//режем картинку, поскольку на используемом сайте картинки просто на фоне т.к он используеться для фона а в нашей выдаче они будут мелкие
 }	
$output.='
<div onclick="showmodal(\''.$frame.'\',\'Modal'.$name.'\');" class="col-md-6 col-lg-4 mb-5">
                        <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#Modal'.$name.'">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div><img class="img-fluid" style="width:100%;height:100%;" src="'.'cache/'.$filename.'" alt="'.$name.'"/>
                        </div>
                    </div>';
	
}
echo $output;
die;
}
if(isset($_POST['video']) and $_POST['video'] ==='video'){ //работает при аякс триггере видео уроков просмотр страницы
exit(getpage('https://ardius.net/belissimo-video')); //при запросе одностраничных шаблонов 
}
if(isset($_POST['update']) and strlen($_POST['href'])>0){ //работает при аякс триггере видео уроков просмотр страницы
download($_POST['href'],'../update.zip');
delDir('../BELISSIMO');
mkdir('../BELISSIMO');
$zip = new ZipArchive;
$res = $zip->open('../update.zip');
if ($res === TRUE) {
  $zip->extractTo('../BELISSIMO');
  $zip->close('../update.zip');
  unlink();
  exit('good');
} else {
$zip->close('../update.zip');
  exit('bad');
}	
die;
}
if(isset($_POST['update']) and $_POST['update']==='update'){ //работает при аякс триггере списка обновлений
exit(getpage('https://ardius.net/belissimo-updates')); //при запросе одностраничных шаблонов 
}

//$out = curl_themewagon('https://themewagon.com/themes/free-bootstrap-5-html5-traveling-landing-page-template-rhea/');
//var_dump($out);
//die;

$install =  $_POST['install']; //работает при аякс триггере установка
$start = microtime(true);
if(count($install)>0){
wayback(); //востановление модекса к состоюнию "из коробки"
download($install,'template.zip'); //скачка выбранного архива
unzip('template.zip'); //распаковка архива
copy('template.zip', '../assets/template.zip'); //перенос архива с шаблоном в папку assets
loger('Перемещён файл','template.zip');
loger('file','../assets/template.zip'); //логируем перенос
unlink('template.zip'); //удаление скачанного архива (мы его выше перенесли и тут он больше не нужен
passer(getpatch('download/')); //запуск парсера и установщика на основе папки в которой будет первой найден index.html
loger('Установка завершена за',round(microtime(true) - $start, 4).' сек.');
die;
}
$install =  $_POST['archive']; //работает при аякс триггере установка из архива
$_POST['name'] = 'archive';
$start = microtime(true);
if(count($install)>0){
wayback(); //востановление модекса к состоюнию "из коробки"
unzip('template.zip'); //распаковка архива
copy('template.zip', '../assets/template.zip'); //перенос архива с шаблоном в папку assets
loger('Перемещён файл','template.zip');
loger('file','../assets/template.zip'); //логируем перенос
unlink('template.zip'); //удаление скачанного архива (мы его выше перенесли и тут он больше не нужен
passer(getpatch('download/')); //запуск парсера и установщика на основе папки в которой будет первой найден index.html
loger('Установка завершена за',round(microtime(true) - $start, 4).' сек.');
die;
}
$pp =  $_POST['getp']; //работает при аякс триггере заспоса контента
$source = $_POST['source']; //тип сайта для вывода
if(sear('html5up.net',$pp)){ //при условии что сайт шаблонов html5up.net
	$html = getpage($pp); //получаем полный код сайта
	preg_match('/<meta name="keywords" content="(.*?)" \/>/',$html,$out); //вырезаем теги шаблона из html тега keywords
	$tags = $out[1]; //присваиваем переменной полученные теги
	preg_match('/<iframe id="demo-iframe" src="(.*?)" width/',$html,$out); //вырезаем ссылку на чистый фрейм без шабки сайта
	$frame = 'https://html5up.net'.$out[1]; //собираем полную ссылку для вывода превью
	preg_match('/\<h1\>\<span\>(.*?)\<\/span\><\/h1\>/',$html,$out); //вырезаем название из полученной старинцы
	$name = $out[1];
	$name = str_replace(' ','-',$name);
	$link = $pp.'/download';
if($sandbox === 1){$sand = 'sandbox';}
echo  '<div class="portfolio-modal modal fade" id="Modal'.$name.'" tabindex="-1" role="dialog" aria-labelledby="#Modal'.$name.'Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" onclick="$(\'#Modal'.$name.'\').fadeOut(500);$(\'#Modal'.$name.'\').remove();" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true"><i class="fas fa-times"></i></span></button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-12"><h2 class="portfolio-modal-title text-secondary mb-0">'.$name.'</h2>
								<div class="divider-custom"></div>
									<iframe src="'.$frame.'"  '.$sand.' frameborder="no" width="100%" height="400px" align="center">
									Ваш браузер не поддерживает встроенные фреймы!
									</iframe>';
if(strlen($tags !=='')){
echo '<p class="mb-5">Теги шаблона: '.$tags.'</p>';
}
$bt = '<button onclick="neww(\''.$frame.'\');" class="btn btn-primary" href="#">
<i class="fas fa-window-maximize"></i>Открыть в новом окне</button>';
echo '
<button onclick="install(\''.$link.'\',\''.$name.'\')" class="btn btn-primary" href="#">
<i class="fas fa-check fa-fw"></i>Установить</button>
'.$bt.'
<button class="btn btn-primary" onclick="$(\'#Modal'.$name.'\').fadeOut(500);$(\'#Modal'.$name.'\').remove();" href="#" data-dismiss="modal"><i class="fas fa-times fa-fw"></i>Закрыть</button>
</div></div></div></div></div></div></div>';
	die;
}
if(sear('html5up',$source)){
	html5up();
}
if(count($pp)>0){
$html = getpage('https://www.free-css.com'.$pp);
preg_match('/this.href\)" href="(.*?)">.*?<\/a><\/li>/',$html,$match);
preg_match('/<span>(.*?) Free CSS Template<\/span>/',$html,$title);
$name = str_replace(' ','-',$title[1]);
if($sandbox === 1){$sand = 'sandbox';}
echo  '
 <div class="portfolio-modal modal fade" id="Modal'.$name.'" tabindex="-1" role="dialog" aria-labelledby="#Modal'.$name.'Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" onclick="$(\'#Modal'.$name.'\').fadeOut(500);$(\'#Modal'.$name.'\').remove();" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true"><i class="fas fa-times"></i></span></button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-12"><h2 class="portfolio-modal-title text-secondary mb-0">'.$title[1].'</h2>
								<div class="divider-custom"></div>
									<iframe src="https://www.free-css.com/'.$match[1].'"  '.$sand.' frameborder="no" width="100%" height="400px" align="center">
									Ваш браузер не поддерживает встроенные фреймы!
									</iframe>
<p class="mb-5">Теги шаблона: ';
$bt = '<button onclick="neww(\'https://www.free-css.com/'.$match[1].'\');" class="btn btn-primary" href="#">
<i class="fas fa-window-maximize"></i>Открыть в новом окне</button>';
 preg_match_all('/<li><a href="\/template-categories\/.*?" title=".*?">(.*?)<\/a><\/li>/',$html,$match);
for($i=0;$i<=count($match[1])-1;$i++){
echo $match[1][$i].'  ';
}
echo '</p>';
preg_match('/<li class="dld"><a rel="nofollow" href="(.*?)" download=".*?\.zip" title=".*?">Download<\/a><\/li>/',$html,$match0);
echo '
<button onclick="install(\'https://www.free-css.com'.$match0[1].'\',\''.$title[1].'\')" class="btn btn-primary" href="#">
<i class="fas fa-check fa-fw"></i>Установить</button>
'.$bt.'
<button class="btn btn-primary" onclick="$(\'#Modal'.$name.'\').fadeOut(500);$(\'#Modal'.$name.'\').remove();" href="#" data-dismiss="modal"><i class="fas fa-times fa-fw"></i>Закрыть</button>
</div></div></div></div></div></div></div>';
 die;	
}
$page = $_POST['page']; //работает при аякс триггере детальный просмотр страницы
if($page !==''){
if(strlen($_POST['sear'])>0){$type = 4;} //Если запрсили по категории
switch ($type) {
    case 0:
        $html = getpage('https://www.free-css.com/free-css-templates?start=12'.$page); //при запросе одностраничных шаблонов
        break;
    case 1:
        $html = getpage('https://www.free-css.com/template-categories/one-page?start='.$page); //при запросе одностраничных шаблонов
        break;
    case 2:
        $html = getpage('https://www.free-css.com/template-categories/multipurpose?start='.$page); //при запросе многостраничных шаблонов
        break;
    case 3:
        $html = getpage('https://www.free-css.com/template-categories/bootstrap?start='.$page);	//при запросе только bootstrap шаблонов
        break;
	case 4:
	    $html = getpage('https://www.free-css.com/template-categories/'.$_POST['sear'].'?start='.$page);	//при по категориям
		break;
	
}
preg_match_all('/><a href="(.*?)" title=".*"><span class="name">(.*?)<\/span> <img src="(.*?)" alt="/',$html,$match);
for($i=0;$i<=count($match[0])-1;$i++){
$filename = explode('/',$match[3][$i]);
$filename = $filename[count($filename)-1];//выдираем название картинки для скачивания
 if(!exist('cache/'.$filename)){ //проверяйм картинки в кеше, если они есть то не скачиваем
download('https://www.free-css.com/'.$match[3][$i],'cache/'.$filename); //сайт защищен от просмотра картинок с другого ip, для этого скачиваем их и выводим локально
 }
$name = str_replace(' ','-',$match[2][$i]);	
echo '
<div onclick="showmodal(\''.$match[1][$i].'\',\'Modal'.$name.'\');" class="col-md-6 col-lg-4 mb-5">
                        <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#Modal'.$match[2][$i].'">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div><img class="img-fluid" style="width:100%;height:100%;" src="'.'cache/'.$filename.'" alt="'.$match[2][$i].'"/>
                        </div>
                    </div>';
}
die;
}
?>
<?php
define('MODX_API_MODE', true);
require '../index.php';			   //---------Подключение API Modx
//[[!+modx.user.id:ne=`0`:then=`<a class="logginedchangeres" target="_blank" href="/manager/?a=resource/update&id=[[*id]]">Редактировать ресурс</a>`:else=``]]
if($modx->getUser()->username ==='(anonymous)' or empty($modx->getUser()->username)){
	header("HTTP/1.1 301 Moved Permanently"); 
 header("Location: /BELISSIMO/error.php"); 
 exit();
}
// A list of permitted file extensions
$allowed = array('zip');

if(isset($_FILES['upl']) && $_FILES['upl']['error'] == 0){

	$extension = pathinfo($_FILES['upl']['name'], PATHINFO_EXTENSION);

	if(!in_array(strtolower($extension), $allowed)){
		echo '{"status":"error"}';
		exit;
	}

	if(move_uploaded_file($_FILES['upl']['tmp_name'], 'template.zip')){
		echo '{"status":"success"}';
		exit;
	}
}

echo '{"status":"error"}';
exit;
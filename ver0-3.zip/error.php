<?php
define('MODX_API_MODE', true);
require '../index.php';			   //---------Подключение API Modx
if($modx->getUser()->username !== '(anonymous)' and !empty($modx->getUser()->username)){
	header("HTTP/1.1 301 Moved Permanently"); 
 header("Location: /BELISSIMO"); 
 exit();
}
require 'libs/js.php'; 	   		   //---------скрипты шаблона (вынесены в отдельный файл для уменьшения нагромаждения)
require 'libs/css.php'; 	   	   //---------стили шаблона (вынесены в отдельный файл для уменьшения нагромаждения)
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>BELISSIMO - Access denied</title>
        <!-- Font Awesome icons (free version)-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" crossorigin="anonymous"></script>
        <?php echo $css;?>

    </head>
    <body id="page-top">
        <header style="height: 100%;position: absolute;width: 100%;top: 0px;left: 0px;" class="masthead bg-primary text-white text-center">
            <div class="container d-flex align-items-center flex-column">
                <!-- Masthead Avatar Image--><img class="masthead-avatar mb-5" id="rabbit0" src="assets/logo.png" alt="">
                <!-- Masthead Heading-->
                <h1 class="masthead-heading mb-0">BELISSIMO - Access denied</h1>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
            </div>
        </header>
        <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes)-->
        <div class="scroll-to-top d-lg-none position-fixed">
		<a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
		<i class="fa fa-chevron-up"></i></a></div>
        <?php  echo $js;?>
    </body>
</html>
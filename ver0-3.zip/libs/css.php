<?php
$css='
<link href="css/styles.css" rel="stylesheet">
<link rel="stylesheet" href="css/heading.css">
<link rel="stylesheet" href="css/body.css">
<link href="css/notifIt.css" type="text/css" rel="stylesheet">
';
?>
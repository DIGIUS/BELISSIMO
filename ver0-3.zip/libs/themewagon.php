<?php
function themewagon($url){ //вывод карточки шаблона
//для этого сайта нужна кука, иначе не получить прямые ссылки на архивы
$curlHandler = curl_init();
curl_setopt_array($curlHandler, [
CURLOPT_URL => $url,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_COOKIEFILE  => $cookieFile,
CURLOPT_COOKIE => 'user_email=belissimo%40ardius.net;',
]);
$response = curl_exec($curlHandler);
curl_close($curlHandler);
$html = $response;
preg_match('/<h5>Tags<\/h5>\n.*<\/div>\n.*<div class="col-sm-7">\n.*<span><span class="single-theme-tax">(.*?)<\/span><\/span>/',$html,$out);
$tags =  $out[1];
preg_match_all('/rel="tag">(.*?)<\/a>/',$tags,$out);
$tags = array();foreach($out[1] as $tag){$tags[]=$tag;}
$tags = implode(', ',$tags); //финальный список тегов
preg_match('/<a class="live-preview-area" target="_blank" href="(.*?)" title="/',$html,$out);
$frame = $out[1]; //ссылка на фрейм
preg_match('/\'name\'\: \'(.*?)\'\,/',$html,$out);
$name = $out[1]; //название шаблона
$name = str_replace(' ','-',$name);
preg_match('/<a id="directDownloadLink" href="(.*?)"/',$html,$out);
$download = $out[1]; //получаем ссылку на скачку
if($sandbox === 1){$sand = 'sandbox';}
echo  '<div class="portfolio-modal modal fade" id="Modal'.$name.'" tabindex="-1" role="dialog" aria-labelledby="#Modal'.$name.'Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" onclick="$(\'#Modal'.$name.'\').fadeOut(500);$(\'#Modal'.$name.'\').remove();" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true"><i class="fas fa-times"></i></span></button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-12"><h2 class="portfolio-modal-title text-secondary mb-0">'.$name.'</h2>
								<div class="divider-custom"></div>
									<iframe src="'.$frame.'"  '.$sand.' frameborder="no" width="100%" height="400px" align="center">
									Ваш браузер не поддерживает встроенные фреймы!
									</iframe>';
if(strlen($tags !=='')){
echo '<p class="mb-5">Теги шаблона: '.$tags.'</p>';
}
$bt = '<button onclick="neww(\''.$frame.'\');" class="btn btn-primary" href="#">
<i class="fas fa-window-maximize"></i>Открыть в новом окне</button>';
echo '
<button onclick="install(\''.$download.'\',\''.$name.'\');$(\'#Modal'.$name.'\').remove();" class="btn btn-primary" href="#">
<i class="fas fa-check fa-fw"></i>Установить</button>
'.$bt.'
<button class="btn btn-primary" onclick="$(\'#Modal'.$name.'\').fadeOut(500);$(\'#Modal'.$name.'\').remove();" href="#" data-dismiss="modal"><i class="fas fa-times fa-fw"></i>Закрыть</button>
</div></div></div></div></div></div></div>';
die;
}
function themewagon_card($pp,$page_num=1){ //вывод каталога карточек
$retu = '';
$html = getpage($pp.$page_num);	
$ht = explode('<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 theme-card-wrap">',$html);
foreach($ht as $pass){
if(!sear('live Preview',$pass)){continue;}
preg_match('/type="image" data-lazy-src="(.*?)" class="lazy/',$pass,$out);
$img = $out[1];
preg_match('/<h2>(.*?)<\/h2>/',$pass,$out);
$name = $out[1];
preg_match('/class="theme-card-anchor" href="(.*?)" title="/',$pass,$out);
$frame = $out[1];
$filename = basename($img);
if(!exist('cache/'.$filename)){ //проверяйм картинки в кеше, если они есть то не скачиваем
download($img,'cache/'.$filename); //сайт защищен от просмотра картинок с другого ip, для этого скачиваем их и выводим локально
}
$retu.='
<div onclick="showmodal(\''.$frame.'\',\'Modal'.$name.'\');" class="col-md-6 col-lg-4 mb-5">
                        <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#Modal'.$name.'">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div><img class="img-fluid" style="width:100%;height:100%;" src="'.'cache/'.$filename.'" alt="'.$name.'"/>
                        </div>
                    </div>';
	
}
echo $retu;	
die;						
}
?>
<?php
function html5up(){  //вывод каталога карточек
$output = '';
$html = getpage('https://html5up.net/'); //получаем полный код сайта
preg_match('/<div\sid=\"items\"\>(.*?)\<\/body>/',$html,$out);//получаем ныжный кусок со всеми шаблонами
$html = $out[1];//получаем ныжный кусок со всеми шаблонами в первой ячейке парсинга
preg_match_all('/<article(.*?)<\/article>/',$html,$out); //режем код по блокам с шаблонами
foreach($out[1] as $html){ //начинаем цикл перебора кода с шаблонами
	preg_match('/class\=\"placeholder\"\salt="(.*?)"\s\/>/',$html,$out); //вырезаем название шаблона из альт тега
	$name = $out[1];
	$name = str_replace(' ','-',$name);
	//echo $name.PHP_EOL; //для отладки
	preg_match('/"\sdata\-src\=\"(.*?)\"\sclass\=\"placeholder\"?/',$html,$out); //вырезаем картинку из src
	$img = 'https://html5up.net/'.$out[1]; //собираем полную ссылку на сайт вместе с главной ссылкой на сайт
	//echo $img.PHP_EOL; //для отладки
	preg_match('/<\/span>Demo<\/a><a href="(.*?)" class="?/',$html,$out); //вырезаем ссылку на скачивание шаблона с сайта
	$link = 'https://html5up.net'.$out[1]; //собираем полную ссылку для скачивания вместе с главной ссылкой на сайт
	//echo $link.PHP_EOL; //для отладки
	preg_match('/class="actions"><a href="(.*?)" class="button demo"><span>Live <\/span>Demo<\/a>?/',$html,$out); //вырезаем ссылку на страницу предпросмотра
	$frame = 'https://html5up.net'.$out[1]; //собираем полную ссылку для просмотра превью вместе с главной ссылкой на сайт
	$filename = basename($img);
	if(!exist('cache/'.$filename)){ //проверяйм картинки в кеше, если они есть то не скачиваем
download($img,'cache/'.$filename); //сайт защищен от просмотра картинок с другого ip, для этого скачиваем их и выводим локально
edit_image('cache/'.$filename,'cache/'.$filename,69,102,650,270);//режем картинку, поскольку на используемом сайте картинки просто на фоне т.к он используеться для фона а в нашей выдаче они будут мелкие
 }	
$output.='
<div onclick="showmodal(\''.$frame.'\',\'Modal'.$name.'\');" class="col-md-6 col-lg-4 mb-5">
                        <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#Modal'.$name.'">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div><img class="img-fluid" style="width:100%;height:100%;" src="'.'cache/'.$filename.'" alt="'.$name.'"/>
                        </div>
                    </div>';
	
}
echo $output;
die;
}
function html5up_card($pp){ //вывод карточки шаблона
	$html = getpage($pp); //получаем полный код сайта
	preg_match('/<meta name="keywords" content="(.*?)" \/>/',$html,$out); //вырезаем теги шаблона из html тега keywords
	$tags = $out[1]; //присваиваем переменной полученные теги
	preg_match('/<iframe id="demo-iframe" src="(.*?)" width/',$html,$out); //вырезаем ссылку на чистый фрейм без шабки сайта
	$frame = 'https://html5up.net'.$out[1]; //собираем полную ссылку для вывода превью
	preg_match('/\<h1\>\<span\>(.*?)\<\/span\><\/h1\>/',$html,$out); //вырезаем название из полученной старинцы
	$name = $out[1];
	$name = str_replace(' ','-',$name);
	$link = $pp.'/download';
if($sandbox === 1){$sand = 'sandbox';}
echo  '<div class="portfolio-modal modal fade" id="Modal'.$name.'" tabindex="-1" role="dialog" aria-labelledby="#Modal'.$name.'Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" onclick="$(\'#Modal'.$name.'\').fadeOut(500);$(\'#Modal'.$name.'\').remove();" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true"><i class="fas fa-times"></i></span></button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-12"><h2 class="portfolio-modal-title text-secondary mb-0">'.$name.'</h2>
								<div class="divider-custom"></div>
									<iframe src="'.$frame.'"  '.$sand.' frameborder="no" width="100%" height="400px" align="center">
									Ваш браузер не поддерживает встроенные фреймы!
									</iframe>';
if(strlen($tags !=='')){
echo '<p class="mb-5">Теги шаблона: '.$tags.'</p>';
}
$bt = '<button onclick="neww(\''.$frame.'\');" class="btn btn-primary" href="#">
<i class="fas fa-window-maximize"></i>Открыть в новом окне</button>';
echo '
<button onclick="install(\''.$link.'\',\''.$name.'\');$(\'#Modal'.$name.'\').remove();" class="btn btn-primary" href="#">
<i class="fas fa-check fa-fw"></i>Установить</button>
'.$bt.'
<button class="btn btn-primary" onclick="$(\'#Modal'.$name.'\').fadeOut(500);$(\'#Modal'.$name.'\').remove();" href="#" data-dismiss="modal"><i class="fas fa-times fa-fw"></i>Закрыть</button>
</div></div></div></div></div></div></div>';
	die;
}
?>
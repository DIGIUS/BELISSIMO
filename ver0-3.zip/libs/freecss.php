<?php
function free_css_card($pp){
$html = getpage('https://www.free-css.com'.$pp);
preg_match('/this.href\)" href="(.*?)">.*?<\/a><\/li>/',$html,$match);
preg_match('/<span>(.*?) Free CSS Template<\/span>/',$html,$title);
$name = str_replace(' ','-',$title[1]);
if($sandbox === 1){$sand = 'sandbox';}
echo  '
 <div class="portfolio-modal modal fade" id="Modal'.$name.'" tabindex="-1" role="dialog" aria-labelledby="#Modal'.$name.'Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" onclick="$(\'#Modal'.$name.'\').fadeOut(500);$(\'#Modal'.$name.'\').remove();" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true"><i class="fas fa-times"></i></span></button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-12"><h2 class="portfolio-modal-title text-secondary mb-0">'.$title[1].'</h2>
								<div class="divider-custom"></div>
									<iframe src="https://www.free-css.com/'.$match[1].'"  '.$sand.' frameborder="no" width="100%" height="400px" align="center">
									Ваш браузер не поддерживает встроенные фреймы!
									</iframe>
<p class="mb-5">Теги шаблона: ';
$bt = '<button onclick="neww(\'https://www.free-css.com/'.$match[1].'\');" class="btn btn-primary" href="#">
<i class="fas fa-window-maximize"></i>Открыть в новом окне</button>';
 preg_match_all('/<li><a href="\/template-categories\/.*?" title=".*?">(.*?)<\/a><\/li>/',$html,$match);
for($i=0;$i<=count($match[1])-1;$i++){
echo $match[1][$i].'  ';
}
echo '</p>';
preg_match('/<li class="dld"><a rel="nofollow" href="(.*?)" download=".*?\.zip" title=".*?">Download<\/a><\/li>/',$html,$match0);
echo '
<button onclick="install(\'https://www.free-css.com'.$match0[1].'\',\''.$title[1].'\');$(\'#Modal'.$name.'\').remove();" class="btn btn-primary" href="#">
<i class="fas fa-check fa-fw"></i>Установить</button>
'.$bt.'
<button class="btn btn-primary" onclick="$(\'#Modal'.$name.'\').fadeOut(500);$(\'#Modal'.$name.'\').remove();" href="#" data-dismiss="modal"><i class="fas fa-times fa-fw"></i>Закрыть</button>
</div></div></div></div></div></div></div>';
 die;	
}
function freecss_page($page){
	if(strlen($_POST['sear'])>0){$type = 4;} //Если запрсили по категории
switch ($type) {
    case 0:
        $html = getpage('https://www.free-css.com/free-css-templates?start=12'.$page); //при запросе одностраничных шаблонов
        break;
    case 1:
        $html = getpage('https://www.free-css.com/template-categories/one-page?start='.$page); //при запросе одностраничных шаблонов
        break;
    case 2:
        $html = getpage('https://www.free-css.com/template-categories/multipurpose?start='.$page); //при запросе многостраничных шаблонов
        break;
    case 3:
        $html = getpage('https://www.free-css.com/template-categories/bootstrap?start='.$page);	//при запросе только bootstrap шаблонов
        break;
	case 4:
	    $html = getpage('https://www.free-css.com/template-categories/'.$_POST['sear'].'?start='.$page);	//при по категориям
		break;
	
}
preg_match_all('/><a href="(.*?)" title=".*"><span class="name">(.*?)<\/span> <img src="(.*?)" alt="/',$html,$match);
for($i=0;$i<=count($match[0])-1;$i++){
$filename = explode('/',$match[3][$i]);
$filename = $filename[count($filename)-1];//выдираем название картинки для скачивания
 if(!exist('cache/'.$filename)){ //проверяйм картинки в кеше, если они есть то не скачиваем
download('https://www.free-css.com/'.$match[3][$i],'cache/'.$filename); //сайт защищен от просмотра картинок с другого ip, для этого скачиваем их и выводим локально
 }
$name = str_replace(' ','-',$match[2][$i]);	
echo '
<div onclick="showmodal(\''.$match[1][$i].'\',\'Modal'.$name.'\');" class="col-md-6 col-lg-4 mb-5">
                        <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#Modal'.$match[2][$i].'">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div><img class="img-fluid" style="width:100%;height:100%;" src="'.'cache/'.$filename.'" alt="'.$match[2][$i].'"/>
                        </div>
                    </div>';
}
die;
}
?>
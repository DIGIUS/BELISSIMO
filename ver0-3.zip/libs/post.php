<?php
$post_event = $_POST['post_event'];
if(isset($post_event)){ //получаем пост запросом требуемое событие если оно вообще есть
switch ($post_event) {  //в зависимости от полученного события мы делаем:
    case 'clean':		//очистку от шаблонов
        wayback();		//Функция отката установки
		exit('good'); 
    case 'video':		//список видео уроков
        exit(getpage('https://ardius.net/belissimo-video'));
    case 'dev':			//список помошников
        exit(getpage('https://ardius.net/belissimo-support'));
	case 'update':			//список обновлений
        exit(getpage('https://ardius.net/belissimo-updates'));
	case 'log':			//вывод файла установки для вывода в "консоль" при установке
        exit(read('install.log')); 
	case  'go_update':		//получаем ссылку на обнову и обновляемся
	download($_POST['href'],'../update.zip'); //качаем обновление
	if(!exist('../update.zip')){exit('bad');} //проверяем скачку и выдаем уведомление если файла нет
	//если файл есть
	delDir('../BELISSIMO'); //сносим текущую папку с содержимым
	//извлекаем содержимое
	$zip = new ZipArchive;
	$res = $zip->open('../update.zip');
	if ($res === TRUE) {
	$zip->extractTo('../BELISSIMO');
	$zip->close();
	//если все хорошо
	unlink('../update.zip');  //сносим скачанный файл обновления, так как мы его уже извлекли
	exit('good'); //говорим что всё ок и можно обновлять страницу.
	} else {
	//если извлечь не получилось
	exit('bad');  //возвращаем что лучше ручками устанавливать ибо извлечь не смогли
	}	
	exit('bad'); //если как то дошли до этого момента и не вышли раньше то отправляем сообщение о неудаче
	
}	
}
$install =  $_POST['install']; //работает при аякс триггере установка
$start = microtime(true);
if(count($install)>0){ //установка с помощью парсера скаченного автоматически шаблона
wayback(); //востановление модекса к состоюнию "из коробки"
download($install,'template.zip'); //скачка выбранного архива
unzip('template.zip'); //распаковка архива
copy('template.zip', '../assets/template.zip'); //перенос архива с шаблоном в папку assets
loger('Перемещён файл','template.zip');
loger('file','../assets/template.zip'); //логируем перенос
unlink('template.zip'); //удаление скачанного архива (мы его выше перенесли и тут он больше не нужен
$home = passer(getpatch('download/')); //запуск парсера и установщика на основе папки в которой будет первой найден index.html
loger('Установка завершена за',round(microtime(true) - $start, 4).' сек.');
exit($home);
}
$install =  $_POST['archive']; //работает при аякс триггере установка из архива
$_POST['name'] = 'archive';$start = microtime(true);
if(count($install)>0){ //установка с помощью парсера загруженного вручную шаблона
wayback(); //востановление модекса к состоюнию "из коробки"
unzip('template.zip'); //распаковка архива
copy('template.zip', '../assets/template.zip'); //перенос архива с шаблоном в папку assets
loger('Перемещён файл','template.zip');
loger('file','../assets/template.zip'); //логируем перенос
unlink('template.zip'); //удаление скачанного архива (мы его выше перенесли и тут он больше не нужен
$home = passer(getpatch('download/')); //запуск парсера и установщика на основе папки в которой будет первой найден index.html
loger('Установка завершена за',round(microtime(true) - $start, 4).' сек.');
exit($home);
die;
}
$pp =  $_POST['getp']; //работает при аякс триггере заспоса контента
$source = $_POST['source']; //тип сайта для вывода
$page = $_POST['page']; //работает при аякс триггере детальный просмотр страницы
?>
<?php
function exist($file){ //поиск файла в папке
	if (file_exists($file)) {
    return true;
} else {
    return false;
}
}
function unzip($file){ //разархивация зип архива только в папку downloads
$zip = new ZipArchive;
$res = $zip->open($file);
if ($res === TRUE) {
  $zip->extractTo('download/');
  $zip->close();
  return true;
} else {
  return false;
}	
}
function sear($word,$text){ //найти слово в тексте
$pos=strripos($text, $word);
if($pos === false){return false;}else{return true;}
}
function download($FromLocation,$ToLocation,$VerifyPeer=false,$VerifyHost=false){ //для скачки файлов
		$Channel = curl_init($FromLocation);
		$File = fopen ($ToLocation, "w");
		curl_setopt($Channel, CURLOPT_FILE, $File);
		curl_setopt($Channel, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($Channel, CURLOPT_HEADER, 0);
		curl_setopt($Channel, CURLOPT_SSL_VERIFYPEER, $VerifyPeer);
		curl_setopt($Channel, CURLOPT_SSL_VERIFYHOST, $VerifyHost);
		curl_exec($Channel);
		curl_close($Channel);
		fclose($File);
	return file_exists($ToLocation);
}
function getpage($url){ //получение кода сороннего сайта для парсинга
        $user_agent='Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0';

        
					$options = array(
		
			CURLOPT_SSL_VERIFYPEER => '0',
			CURLOPT_SSL_VERIFYHOST => '0',
            CURLOPT_CUSTOMREQUEST  =>"GET",
            CURLOPT_POST           =>false,
            CURLOPT_USERAGENT      => $user_agent,
            CURLOPT_COOKIEFILE     =>"cookie.txt",
            CURLOPT_COOKIEJAR      =>"cookie.txt",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING       => "",
            CURLOPT_AUTOREFERER    => true,
            CURLOPT_CONNECTTIMEOUT => 120,
            CURLOPT_TIMEOUT        => 120,
            CURLOPT_MAXREDIRS      => 10);
        $ch      = curl_init( $url );
        curl_setopt_array( $ch, $options );
        $content = curl_exec( $ch );
        $err     = curl_errno( $ch );
        $errmsg  = curl_error( $ch );
        $header  = curl_getinfo( $ch );
        curl_close( $ch );
        return $content;
}
function delDir($dir) { //удаление папки с её содержимым
    $files = array_diff(scandir($dir), ['.','..']);
    foreach ($files as $file) {
        (is_dir($dir.'/'.$file)) ? delDir($dir.'/'.$file) : unlink($dir.'/'.$file);
    }
    return rmdir($dir);
}
function loger($type,$val){ //создание файла с историей установки 
$fp = fopen('install.log', 'a');
fwrite($fp, "$type => $val\n");
fclose($fp);
}
function getfiletype($name){ //получение расширения файла примитивнийшим способом
return	substr($name, strrpos($name, '.' ) + 1 ); //получение расширения файла
}
function wayback(){ //для отката предыдущей установки шаблона
global $modx;
$story = read('install.log');
preg_match_all('/(.*?) => (.*?)\n/',$story,$story);
$story[1] = array_reverse($story[1]); //переворачиваем массивы поскольку нужно сначала удалить шаблоны а потом категорию. Так как процесс создания  другой: сначала категория, потом щаблоны.
$story[2] = array_reverse($story[2]);
for($i=0;$i<count($story[1]);$i++){
	switch ($story[1][$i]) {
    case 'category':
       rcategory(intval($story[2][$i]));
        break;
    case 'folder':
        delDir($story[2][$i]);
        break;
    case 'template':
        rtemplate($story[2][$i]);
        break;
	case 'res':
        rres($story[2][$i]);
        break;
	case 'chunk':
        rchunk($story[2][$i]);
        break;
	case 'file':
        unlink($story[2][$i]);
        break;
}
}
unlink('install.log'); //Удаление предыдущего файла истории установки
delDir('download/'); //удаление папки старых файлов 
$modx->cacheManager->refresh();
mkdir('download/'); //создание папки для скачанных файлов
$files = array_diff(scandir('../assets/'), array('..', '.'));
foreach ($files as $file):
if($file !== 'components'){
delDir('../assets/'.$file); //удаление старых папок кроме папки модкс components
}
endforeach;
unlink('install.log');
}
function chunk($name,$category,$content){ //функция добавления чанка
global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$modx->getService('error','error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_FATAL);
$modx->setLogTarget(XPDO_CLI_MODE ? 'ECHO' : 'HTML'); 
$chunk = $modx->newObject('modChunk');
$chunk->set('name',$name);
$chunk->set('category',$category);
$chunk->setContent($content);
$chunk->save();
$chunk->getPrimaryKey();
return $chunk->get('id');
}
function rchunk($id){ //функция удаления чанка
if(strlen($id)<=0){return;}
global $modx; 
$modx = new modX();
$modx->initialize('web');
$modx->getService('error','error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_FATAL);
$modx->setLogTarget(XPDO_CLI_MODE ? 'ECHO' : 'HTML'); 
$rchunk = $modx->getObject('modChunk', array('id' => $id));
if ($rchunk) $rchunk->remove();
}
function template($name,$category,$content){ //функция добавления шаблона
global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$template = $modx->newObject('modTemplate');
$template->set('templatename',$name);
$template->set('category',$category);
$template->setContent($content);
$template->save();
$template->getPrimaryKey();
return $template->get('id');
}
function rtemplate($id){ //Функция удаления шаблона
if(strlen($id)<=0){return;}
global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$modx->getService('error','error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_FATAL);
$modx->setLogTarget(XPDO_CLI_MODE ? 'ECHO' : 'HTML'); 
$rtemplate = $modx->getObject('modTemplate', array('id' => $id));
if ($rtemplate) $rtemplate->remove();
}
function category($name){ //Функция добавления шаблона
	global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$modx->getService('error','error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_FATAL);
$modx->setLogTarget(XPDO_CLI_MODE ? 'ECHO' : 'HTML'); 
$template = $modx->newObject('modCategory');
$template->set('parent','0');
$template->set('category',$name);
$template->save();
$template->getPrimaryKey();
return $template->get('id');
}
function rcategory($id){ //Функция удаления категории
if(strlen($id)<=0){return;}
	global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$modx->getService('error','error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_FATAL);
$modx->setLogTarget(XPDO_CLI_MODE ? 'ECHO' : 'HTML'); 
$category = $modx->getObject('modCategory', array('id' => $id));
if ($category) $category->remove();
}
function res($name,$category,$parent,$content){ //Функция добавления ресурса
global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$template = $modx->newObject('modResource');
$template->set('template',$category);
$template->set('alias',$name.' Ardius installed');
$template->set('parent',$parent);
$template->set('content',$content);
$template->set('published',1);
$template->set('pagetitle',$name);
$template->save();
$template->getPrimaryKey();
return $template->get('id');	
}
function rres($id){ //Функция удаления ресурса
if(strlen($id)<=0){return;}
global $modx; //глобальная прееменная для доступа к апи модкс
$modx = new modX();
$modx->initialize('web');
$res = $modx->getObject('modResource', array('id' => $id));
if ($res) $res->remove(); //удаляем окончательно
}
function read($file){ //для того чтоб кодить было быстрее и писать меньше
return	file_get_contents($file); 
}
function getpatch($path){ //index.html или index.htm поиск в папках и вывод папки
	$path = new RecursiveDirectoryIterator($path);
$display = Array ( 'html', 'htm' );
foreach(new RecursiveIteratorIterator($path) as $file){
    if (in_array(strtolower(array_pop(explode('.', $file))), $display)){
        if(sear('index',$file)){
			$pp = str_replace('\\','/',$file);
			$pp = explode('/',$pp);
			array_pop($pp);
			$pp = implode("/", $pp).'/';
			return $pp;
		}
	}
}
}
function passer($path){ //основная функция, парсит, переносит, создаёт чанки, категорию, ресурсы и подгоняет под структуру Modx revo
global $modx;
$home_uri = '';
$dir = array(); //массив для папок
$file = array(); //массив  для файлов
$files = scandir($path); //Получение списка файлов и папок в скачанной папке с шаблоном
for($i=2;$i<count($files);$i++){ //убрать из массива . и .. 
if(is_dir($path.$files[$i])){$dir[$i] = $files[$i];}  //в массив с папками 
if(is_file($path.$files[$i])){$file[$i] = $files[$i];}	//в массив с файлами
}
$dir = array_diff($dir, array('')); $file = array_diff($file, array(''));//удалить из массива пустые значения
$category = category($_POST['name']); //Создание категории чтоб небыло захламлённости и получение её ID
loger('Устанавливаемый шаблон ', $_POST['name'].', ссылка на шаблон '.$install); 
loger('Добавлена категория',$category);
loger('category',$category); //Добавление в лист установки ID нашей новой категории
$parent = res($_POST['name'],'0','0','Сгенерированно автоустановщиком шаблонов от Ardius.net
Отблагодорить можно через Ядекс.Деньги: 41001752083175');
loger('Добавлен ресурс',$parent);
loger('res',$parent); //Добавление в лист установки ID нашего нового родительского документа
foreach($dir as $np){//преемещение папок с ресурсами в папку asstes
loger('Перенесена папка в','../assets/'.$np);
loger('folder','../assets/'.$np); //добавление в гол файлов которые были перемещенны
rename($path.$np, '../assets/'.$np);
delDir($path.$np);
}
foreach($file as $np){//перебор всех файлов из папки с шаблоном
$html = read($path.$np);//чтение файла в переменную
if(sear('.html',$np) or sear('.htm',$np)){//если тпи фалов .html или .htm	
global $link;
if($link){ //если ссылки отключены, то не будут генерироваться
preg_match_all('/href="(.*?)"/',$html,$out);
foreach($out[0] as $href){
if(!sear('.css',$href)  and !sear('.js',$href)  and !sear('#',$href) and !sear('"tel:',$href) and !sear('"geo:',$href) and !sear('"mailto:',$href)){
foreach($file as $npp){//перебор всех файлов для замены ссылок
	$name = preg_replace("/\.[^.]+$/", "", $npp);
	$name = str_replace('/','-',$name);
	$name = str_replace('_','-',$name);
	$name = str_replace('.','-',$name);
	$name = str_replace('\\','-',$name);
	$html = str_replace($npp,'/'.$name.'-ardius-installed',$html);
}
}
}
}	
//восстанавливаем пути к скриптам и стилям после смены их папки
foreach($dir as $ns){
	$html = str_replace('="'.$ns,'="/assets/'.$ns,$html); //по хорошему установку предварительно нужно запихнуть в массив, потом открывать уже ресурсы и менять в них в соответствии с id, но это долго и мне пока лень...
}
//тут все предварительно 
//так как регулярки не распространяются на творчество разработчиков и все предугадать невозможно, но шаблонные варианты далее попробуем получить
//раскидываем общие значения по чанкам
global $chunks;
if($chunks){ //если чанки отключены, то не будут генерироваться
//Парсим META (если есть по паттерну)
preg_match_all('/<meta(?:.|\n|\r)+?>/',$html,$out); //получение всех js скриптов страницы
$meta = implode("\r\n", $out[0]); //сохранение всех js страницы в переменную
$last = array_pop($out[0]);
foreach($out[0] as $ext){
if(strlen($ext)> 0 and sear('<meta',$ext)){ //если находим то переводим в чанк, и чанк ставим в код
$html = str_replace($ext, '',$html);
}
}
$chunk =  chunk('meta_'.$_POST['name'],$category,$meta);
$html = str_replace($last, '[[$meta_'.$_POST['name'].']]',$html);	
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
//Парсим JS (если есть по паттерну)
preg_match_all('/<script.*?src=\"(.*?)\"/',$html,$out); //получение всех js скриптов страницы
$js = implode("\r\n", $out[0]); //сохранение всех js страницы в переменную
$last = array_pop($out[0]);
foreach($out[0] as $ext){
if(strlen($ext)> 0 and sear('<script',$ext)){ //если находим то переводим в чанк, и чанк ставим в код
$html = str_replace('="'.$ext, '',$html);
}
}
$chunk =  chunk('js_'.$_POST['name'],$category,$js);
$html = str_replace($last, '[[$js_'.$_POST['name'].']]',$html);	
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
//Парсим CSS (если есть по паттерну)
preg_match_all('/<link(?:.|\n|\r)+?>/',$html,$out); //получение всех css стилей страницы
$css = implode("|", $out[0]); //сохранение всех css страницы в переменную
preg_match_all('/<style(?:.|\n|\r)+?<\/style>/',$html,$out); //проверка стилей указанных вручную как это обычно бывает
if(count($out[0])===1){ //если в массиве единственное значение то implode не сработает
	$css.='|'.$out[0][0];
}else{
	$css.= implode("|", $out[0]);
}
$out = explode('|',$css);
$first= $out[0];
if(strlen($first)> 0 and sear('<\/style>',$first) or strlen($first)> 0 and sear('<link',$first)){ //если находим то переводим в чанк, и чанк ставим в код
foreach($out as $ext){
if($ext !== $first){
$html = str_replace('="'.$ext,'',$html);
}	
}
$css = str_replace('|',"\r\n",$css);
$chunk =  chunk('css_'.$_POST['name'],$category,$css);
$html = str_replace($first, '[[$css_'.$_POST['name'].']]',$html);
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);	
}
//Парсим HEAD (если есть по паттерну)
preg_match_all('/<head(?:.|\n|\r)+?head>/',$html,$out); //предварительное получение head
$head = $out[0][0]; //сохранение head страницы в переменную
if(strlen($head)>0 and sear('<head',$head) and sear('</head',$head)){ //если находим то переводим в чанк, и чанк ставим в код
$chunk =  chunk('head_'.$_POST['name'],$category,$head);
$html = str_replace($head, '[[$head_'.$_POST['name'].']]',$html);	
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
}
//Парсим FOOTER (если есть по паттерну)
preg_match_all('/<footer(?:.|\n|\r)+?footer>/',$html,$out); //предварительное получение footer
$footer = $out[0][0]; //сохранение footer страницы в переменную
if(strlen($footer)>0 and sear('<footer',$footer) and sear('</footer',$footer)){ //если находим то переводим в чанк, и чанк ставим в код
$chunk =  chunk('footer_'.$_POST['name'],$category,$footer);
$html = str_replace($footer, '[[$footer_'.$_POST['name'].']]',$html);	
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
}
//Парсим HEADER (если есть по паттерну)
preg_match_all('/<header(?:.|\n|\r)+?header>/',$html,$out); //предварительное получение header
$header = $out[0][0]; //сохранение header страницы в переменную
if(strlen($header)>0 and sear('<header',$header) and sear('</header',$header)){ //если находим то переводим в чанк, и чанк ставим в код
$chunk =  chunk('header_'.$_POST['name'],$category,$header);
$html = str_replace($header, '[[$header_'.$_POST['name'].']]',$html);	
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
}
//Парсим NAV (если есть по паттерну)
preg_match_all('/<nav(?:.|\n|\r)+?nav>/',$html,$out); //предварительное получение nav
$nav = $out[0][0]; //сохранение nav страницы в переменную
if(strlen($nav)>0 and sear('<nav',$nav) and sear('</nav>',$nav)){ //если находим то переводим в чанк, и чанк ставим в код
	$chunk =  chunk('navigation_'.$_POST['name'],$category,$nav);
	$html = str_replace($nav, '[[$navigation_'.$_POST['name'].']]',$html);
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);	
}
//preg_match_all('/<body(?:.|\n|\r)+?body>/',$html,$out); //предварительное получение body
//$body = $out[0][0]; //сохранение body страницы в переменную
//сохранение вариантов верстки
//я определил 3: первый секциями, второй вместо секций использует div с спец классом, третий неструктурированный и следовательно нерабочий для данного шаблонизатора
//триггерить эти блоки будем по словам: id="contact", class="contact"  
//тут мы и берём тесты верстки
//1 тип <section, пример кода: <section id="contact">
//Парсим SECTION (если есть по паттерну)
preg_match_all('/<section(?:.|\n|\r)+?<\/section>/',$html,$out);$last = $out[0][count($out[0])-1];
if(strlen($last)> 0 and sear('<section',$last)){ //если находим то переводим в чанк, и чанк ставим в код
$sec = 0;
foreach($out[0] as $sect){
$chunk =  chunk('section_'.$_POST['name'].'_'.preg_replace("/\.[^.]+$/", "", $np).'_'.$sec,$category,$sect);
$html = str_replace($sect, '[[$section_'.$_POST['name'].'_'.preg_replace("/\.[^.]+$/", "", $np).'_'.$sec.']]',$html);
loger('Добавлен чанк',$chunk);	
loger('chunk',$chunk);
$sec++;	
}
}
//2 тип <div class="contact", пример кода: <div class="contact" id="contact">
}
$template =  template(preg_replace("/\.[^.]+$/", "", $np),$category,$html);
loger('Создан шаблон',preg_replace("/\.[^.]+$/", "", $np));
loger('template',$template); //Добавление в лист установки ID нашего нового шаблона
$res = res(preg_replace("/\.[^.]+$/", "", $np),$template,$parent,'');
$alias = $modx->getObject('modResource', $res)->get('uri');
if(sear('index',$alias) and empty($home_uri)){
$protocol = strpos(strtolower($_SERVER['SERVER_PROTOCOL']), 'https') === FALSE ? 'http://' : 'https://';
$home_uri = $protocol.$_SERVER['HTTP_HOST'].'/'.$alias;
}
loger('Создан ресурс',preg_replace("/\.[^.]+$/", "", $np));
loger('res',$res); //Добавление в лист установки ID нашего нового родительского документа
}
if(!sear('.htm',$np) and !sear('.html',$np)){	!//если не файлы для шаблонов
//if($np !== 'config.core.php' or $np !== 'config.core.php' or $np !== '.htaccess'){ //защита если выложат шаблон с "кривыми файлами"
copy($path.$np, '../'.$np); //перенос файлов в основную папку сайта
loger('Скопирован файл в','../'.$np);
loger('file','../'.$np); //логируем перенос
unlink($path.$np); //удаление файлов из папки шаблона
//}
}
}
return $home_uri;
}
function edit_image($in,$out,$l,$r,$u,$d){ //функция обрезки изображений, агрументами принимает: входное изображение, выходное изображение, отрезать: x, y , ширина и высота
$image = new Thumbs($in);
$image->crop($l, $l, $u, $d);
$image->save($out);
}
function main_doc_url(){
	
}
?>
<?php
/*
не балуйтесь с exit(); и die; и другими останавливающими работу скрипта вещами (рискуете вручную удалять все что автоустановщик поставит), 
юзайте только функции и процедуры без остановки работы скрипта, например: var_dump, echo, print_r.
*/
define('MODX_API_MODE', true);
require '../index.php';			   //---------Подключение API Modx
//[[!+modx.user.id:ne=`0`:then=`<a class="logginedchangeres" target="_blank" href="/manager/?a=resource/update&id=[[*id]]">Редактировать ресурс</a>`:else=``]]
if($modx->getUser()->username ==='(anonymous)' or empty($modx->getUser()->username)){
	header("HTTP/1.1 301 Moved Permanently"); 
 header("Location: /BELISSIMO/error.php"); 
 exit();
}
require 'libs/phptumb.php';        //---------Библиотека для работы с картинками
//*----------------------->Парсеры сайтов начало<-----------------------//
require 'libs/html5up.php'; 	   //---------Парсер сайта html5up.net
require 'libs/freecss.php'; 	   //---------Парсер сайта free-css.com
require 'libs/themewagon.php'; 	   //---------Парсер сайта themewagon.com
//*----------------------->Парсеры сайтов конец<-----------------------//
require 'libs/belissimo_core.php'; //---------Функции основного "ядра" BELISSIMO, ядро нужно сказать чистый говнокод а не изумруд. Хотите лучше?, перепишите и помогите проекту!
set_time_limit(36000);             //---------Максимальное время выполнения скрипта
ini_set("memory_limit", "1000M");  //---------Лимит памяти для скрипта
global $chunks,$link,$type;        //---------Объявление глобальных переменных
$chunks = false; // триггер автопереноса по чанкам (относительно корректно работает для одностраничников)
$link = true; // триггер авторасстановки ссылок
$type = 0; // по умолчанию искать все типы шаблонов
if(isset($_POST['sitetype'])){
$type = intval($_POST['sitetype']);
}
$sandbox = 1; //могут ли ссылки открываться из фрейма в текущем окне (некоторые шаблоны из за этого останавливаються на загрузке так как браузер блокирует загрузку скриптов), а некоторые открывают сайт оригинал в этом окне
if(isset($_POST['sandbox'])){
$sandbox = intval($_POST['sandbox']);
}
if($_POST['chunks'] ==='1'){
$chunks = false;	
}else{
$chunks = true;		
}
if($_POST['hrefs'] ==='1'){
$link = false;	
}else{
$link = true;		
}
require 'libs/post.php'; //вызов для получения необходимых для работы BELISSIMO пост запросов
if(sear('themewagon.com',$source)){ //при условии что сайт шаблонов themewagon.com
	themewagon_card($source,$page); //получить список карточек
}
if(sear('themewagon.com',$pp)){ //при условии что сайт шаблонов themewagon.com
	themewagon($pp); //получить список карточек
}
if(sear('html5up.net',$pp)){ //при условии что сайт шаблонов html5up.net
	html5up_card($pp); //получить список карточек
}
if(sear('html5up',$source)){
	html5up(); //получить карточку с фреймом, ссылкой и прочим.
}
if(empty($source) and  count($pp)>0){
	free_css_card($pp); //получить карточку с фреймом, ссылкой и прочим.
}
if($page !==''){
freecss_page($page);
}
?>